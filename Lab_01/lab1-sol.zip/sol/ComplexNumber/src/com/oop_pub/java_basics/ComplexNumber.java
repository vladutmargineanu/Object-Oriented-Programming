package com.oop_pub.java_basics;

class ComplexNumber {
    private float re;
    private float im;

    public float getRe() {
        return re;
    }

    public void setRe(final float r) {
        this.re = r;
    }

    public float getIm() {
        return im;
    }

    public void setIm(final float i) {
        this.im = i;
    }
}

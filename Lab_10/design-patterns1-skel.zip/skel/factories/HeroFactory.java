package factories;

import entities.Hero;

public class HeroFactory {
	//TODO implement me

	/**
	 *
	 * @param type the Hero type
	 * @param name
	 * @return
	 */
	public Hero createHero(Hero.Type type, String name) {
		return null;
	}
}

package entities;

//extra attribute: damage (aka strength)

package entities;

//additional attack: magicAttack
package entities;

//extra attribute: knowledge


import java.util.ArrayList;

public class ImageReader {

    public ArrayList<RGBPoint> readFile(String filename) {

        ArrayList<RGBPoint> image = new ArrayList<>();



        return null;

    }
}

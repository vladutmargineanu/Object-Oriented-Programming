package com.oop_pub.visitor;

public interface Visitable {
    void accept(Visitor v);
}

package Implementations;

//TODO implementati interfata Visitable
public class Intern {

    private String  name;
    private int duration;  // in months

    public String getName() {
        return name;
    }
}

package Implementations;

public interface Visitable {
    void accept(Visitor v);
}
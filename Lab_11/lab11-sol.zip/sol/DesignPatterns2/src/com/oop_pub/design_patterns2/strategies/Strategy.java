package com.oop_pub.design_patterns2.strategies;

import com.oop_pub.design_patterns2.entities.Monster;

public interface Strategy {
    void attack(Monster m);
}

package com.oop_pub.design_patterns2.commands;

public interface Command {
    void undo();

    void execute();
}

package commands;

import entities.Hero;

public class MoveCommand implements Command {

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

    // TODO implement the move command
    /*  - MoveCommand(Hero, Direction)
        - void undo()
        - void execute()
        - maybe helper method for undo ?
    */
}

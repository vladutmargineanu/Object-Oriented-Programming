package commands;

import java.util.Stack;

public class CommandManager {

    // TODO
    /* - void undo()
       - void redo()
       - void executeCommand(Command c)
       - maybe check if undo() and redo() are available ?
             -> check GameState class, see the errors
       - keep track of the commands somehow
    */

    // public void executeCommand(Command c) {}
    // public void undo() {}
    // public void redo() {}
}

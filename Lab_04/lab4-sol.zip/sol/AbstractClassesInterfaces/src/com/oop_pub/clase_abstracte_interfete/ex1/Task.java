package com.oop_pub.clase_abstracte_interfete.ex1;

public interface Task {

    /**
     * Executes the action characteristic of the task.
     */
    void execute();
}

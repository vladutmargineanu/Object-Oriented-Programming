package com.oop_pub.clase_abstracte_interfete.ex3;

/**
 * Enumerates the types of strategies for the containers.
 */
public enum Strategy {
    FIFO, LIFO
}
